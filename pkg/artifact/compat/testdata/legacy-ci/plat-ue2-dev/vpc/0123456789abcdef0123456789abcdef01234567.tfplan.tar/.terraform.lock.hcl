# legacy lock file
provider "registry.terraform.io/hashicorp/aws" {
  version = "5.0.0"
}
